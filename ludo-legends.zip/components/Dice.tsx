import React, { useEffect, useState } from 'react';

interface DiceProps {
  value: number | null;
  rolling: boolean;
  onRoll: () => void;
  disabled: boolean;
  color: string;
}

const Dice: React.FC<DiceProps> = ({ value, rolling, onRoll, disabled, color }) => {
  const [displayValue, setDisplayValue] = useState(1);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (value) {
      setDisplayValue(value);
      // Random rotation for visual effect
      setRotation({
        x: Math.floor(Math.random() * 4) * 360,
        y: Math.floor(Math.random() * 4) * 360
      });
    }
  }, [value]);

  const getFaceContent = (num: number) => {
    // Generate dots
    const dots = [];
    if ([1, 3, 5].includes(num)) dots.push(<div key="c" className="w-3 h-3 bg-black rounded-full absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />);
    if ([2, 3, 4, 5, 6].includes(num)) dots.push(<div key="tl" className="w-3 h-3 bg-black rounded-full absolute top-2 left-2" />);
    if ([2, 3, 4, 5, 6].includes(num)) dots.push(<div key="br" className="w-3 h-3 bg-black rounded-full absolute bottom-2 right-2" />);
    if ([4, 5, 6].includes(num)) dots.push(<div key="tr" className="w-3 h-3 bg-black rounded-full absolute top-2 right-2" />);
    if ([4, 5, 6].includes(num)) dots.push(<div key="bl" className="w-3 h-3 bg-black rounded-full absolute bottom-2 left-2" />);
    if (num === 6) dots.push(<div key="ml" className="w-3 h-3 bg-black rounded-full absolute top-1/2 left-2 -translate-y-1/2" />);
    if (num === 6) dots.push(<div key="mr" className="w-3 h-3 bg-black rounded-full absolute top-1/2 right-2 -translate-y-1/2" />);
    return dots;
  };

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <button
        onClick={onRoll}
        disabled={disabled || rolling}
        className={`w-16 h-16 relative perspective-1000 ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:scale-105'} transition-all`}
      >
        <div 
          className={`w-full h-full bg-white rounded-xl shadow-lg border-2 border-gray-300 flex items-center justify-center relative overflow-hidden ${rolling ? 'animate-spin' : ''}`}
          style={{
            boxShadow: `0 0 15px ${disabled ? 'gray' : color}`
          }}
        >
          {rolling ? (
            <span className="text-2xl font-bold text-gray-400">?</span>
          ) : (
             <div className="relative w-full h-full">
               {getFaceContent(displayValue)}
             </div>
          )}
        </div>
      </button>
      <div className="mt-2 text-sm font-bold text-gray-300">
        {rolling ? 'Rolling...' : value ? `Rolled: ${value}` : 'Roll Dice'}
      </div>
    </div>
  );
};

export default Dice;