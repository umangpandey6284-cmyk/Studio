import React from 'react';
import { GameState, Pawn, PlayerColor, PawnStatus } from '../types';
import { COLORS, START_INDICES, SAFE_ZONES } from '../constants';

interface GameBoardProps {
  gameState: GameState;
  onPawnClick: (pawn: Pawn) => void;
}

// Coordinate mapping helper
// Returns grid-area or absolute positioning style for a visual cell
const getCellPosition = (index: number) => {
    // This function maps the 15x15 grid index to a spiral path
    // We will just render the grid cells and place pawns absolutely based on calculated coordinates
    // Simplified for this demo: We create the grid, and map global path index to x,y
    return {};
};

// PRE-CALCULATED COORDINATES for a 15x15 Grid (0-14, 0-14)
// Path starts from Red Start (index 0) and goes clockwise
// RED START is usually at (13, 6) relative to top-left (0,0) being top-left
// Let's use standard coordinates:
// Red Home Base: Bottom-Left. Path start: (13, 6) -> move Up to (8,6) -> etc.

// A sequence of [row, col] for the main 52 step path
const MAIN_PATH_COORDS: [number, number][] = [
  // RED Path (Starting just outside Red Base, going UP)
  [13, 6], [12, 6], [11, 6], [10, 6], [9, 6], // 0-4
  [8, 5], [8, 4], [8, 3], [8, 2], [8, 1], [8, 0], // 5-10 (Left wing top)
  [7, 0], // 11 (End of left wing)
  [6, 0], [6, 1], [6, 2], [6, 3], [6, 4], [6, 5], // 12-17 (Left wing bottom, moving right)
  [5, 6], [4, 6], [3, 6], [2, 6], [1, 6], [0, 6], // 18-23 (Top wing left, moving up)
  [0, 7], // 24 (Top center)
  [0, 8], [1, 8], [2, 8], [3, 8], [4, 8], [5, 8], // 25-30 (Top wing right, moving down)
  [6, 9], [6, 10], [6, 11], [6, 12], [6, 13], [6, 14], // 31-36 (Right wing top, moving right)
  [7, 14], // 37 (Right center)
  [8, 14], [8, 13], [8, 12], [8, 11], [8, 10], [8, 9], // 38-43 (Right wing bottom, moving left)
  [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], [14, 8], // 44-49 (Bottom wing right, moving down)
  [14, 7], // 50 (Bottom center)
  [14, 6]  // 51 (Bottom wing left, moving up - completing loop)
];

// Home Paths (Final stretch to center)
const HOME_PATHS: Record<PlayerColor, [number, number][]> = {
  RED: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7], [8, 7]], // UP from bottom
  GREEN: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5], [7, 6]], // RIGHT from left
  YELLOW: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7], [6, 7]], // DOWN from top
  BLUE: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9], [7, 8]], // LEFT from right
};

// Base positions for pawns waiting to start
const BASE_POSITIONS: Record<PlayerColor, [number, number][]> = {
  RED: [[11, 2], [11, 3], [12, 2], [12, 3]],
  GREEN: [[2, 2], [2, 3], [3, 2], [3, 3]],
  YELLOW: [[2, 11], [2, 12], [3, 11], [3, 12]],
  BLUE: [[11, 11], [11, 12], [12, 11], [12, 12]],
};

const GameBoard: React.FC<GameBoardProps> = ({ gameState, onPawnClick }) => {
  
  // Helper to determine where a pawn is on the grid
  const getPawnCoordinates = (pawn: Pawn): { r: number, c: number } => {
    // Base coords static access
    if (pawn.status === PawnStatus.HOME) {
      const pos = BASE_POSITIONS[pawn.color][pawn.id];
      return { r: pos[0], c: pos[1] };
    }

    if (pawn.status === PawnStatus.FINISHED) {
       // Center triangle areas roughly
       const centerMap: Record<PlayerColor, [number, number]> = {
         RED: [9, 7], GREEN: [7, 5], YELLOW: [5, 7], BLUE: [7, 9]
       };
       const center = centerMap[pawn.color];
       return { r: center[0], c: center[1] };
    }

    // Active path logic
    const MAX_MAIN_PATH = 50; // Threshold before turning into home run? 
    // Actually, logic: stepsMoved.
    // Red Start Index is 0. 
    // Total board size 52.
    // stepsMoved goes from 0 to 56.
    // If stepsMoved <= 50, use global path.
    // If stepsMoved > 50, use home path.
    
    if (pawn.stepsMoved <= 50) {
      // Calculate global index based on color start
      const offset = START_INDICES[pawn.color];
      const globalIdx = (offset + pawn.stepsMoved) % 52;
      const coords = MAIN_PATH_COORDS[globalIdx];
      return { r: coords[0], c: coords[1] };
    } else {
      // Home path
      const homeIdx = pawn.stepsMoved - 51; // 0 to 5
      const coords = HOME_PATHS[pawn.color][homeIdx];
      // Handle bounds
      if(!coords) return {r: 7, c: 7}; // Fallback to absolute center
      return { r: coords[0], c: coords[1] };
    }
  };

  const renderCells = () => {
    // We just render the grid background image/css, 
    // but here we render the pawns on top.
    return null; 
  };

  // Group pawns at same position to avoid overlap
  const getPawnsAtPos = (r: number, c: number) => {
    const pawns: Pawn[] = [];
    gameState.players.forEach(p => {
      p.pawns.forEach(pawn => {
        const coords = getPawnCoordinates(pawn);
        if (coords.r === r && coords.c === c) {
          pawns.push(pawn);
        }
      });
    });
    return pawns;
  };

  // Render Grid Background
  // 15x15 Grid
  const renderBoardGrid = () => {
    const cells = [];
    for(let r=0; r<15; r++) {
      for(let c=0; c<15; c++) {
        // Determine cell type for coloring
        let bgClass = "bg-white";
        // Bases (6x6 corners)
        if(r < 6 && c < 6) bgClass = "bg-green-500";
        else if(r < 6 && c > 8) bgClass = "bg-yellow-400";
        else if(r > 8 && c < 6) bgClass = "bg-red-500";
        else if(r > 8 && c > 8) bgClass = "bg-blue-500";
        // Center
        else if(r >= 6 && r <= 8 && c >= 6 && c <= 8) bgClass = "bg-gray-800 diagonal-center"; 
        
        // Render Star/Safe Zones (Manual check)
        const isStar = false; // TODO: Implement safe zone visual

        cells.push(
          <div 
            key={`${r}-${c}`} 
            className={`w-full h-full border-[0.5px] border-gray-300 relative ${bgClass}`}
            style={{
              gridRowStart: r + 1,
              gridColumnStart: c + 1
            }}
          >
            {/* Render Pawns in this cell */}
            <div className="absolute inset-0 flex items-center justify-center flex-wrap p-0.5">
               {getPawnsAtPos(r, c).map((pawn, idx, arr) => {
                 const isClickable = gameState.currentPlayerIndex === gameState.players.findIndex(p => p.color === pawn.color) 
                                     && !gameState.waitingForDice 
                                     && !gameState.players.find(p => p.color === pawn.color)?.isBot;
                 
                 const size = arr.length > 1 ? 'w-3 h-3' : 'w-5 h-5 md:w-6 md:h-6';
                 const colorData = COLORS[pawn.color];
                 
                 return (
                   <button
                    key={`${pawn.color}-${pawn.id}`}
                    onClick={(e) => { e.stopPropagation(); onPawnClick(pawn); }}
                    disabled={!isClickable}
                    className={`${size} rounded-full border-2 border-white shadow-md ${colorData.bg} ${isClickable ? 'animate-bounce cursor-pointer ring-2 ring-white' : ''} transition-transform`}
                    style={{ zIndex: 10 }}
                   />
                 );
               })}
            </div>
          </div>
        );
      }
    }
    return cells;
  };

  return (
    <div className="relative w-full max-w-[500px] aspect-square bg-white shadow-2xl rounded-lg overflow-hidden border-4 border-gray-800">
      <div className="grid grid-cols-15 grid-rows-15 w-full h-full">
        {renderBoardGrid()}
      </div>
      
      {/* Decorative Center Triangles (CSS Overlay) */}
      <div className="absolute top-[40%] left-[40%] w-[20%] h-[20%] pointer-events-none">
          <div className="absolute inset-0 bg-white" style={{clipPath: 'polygon(0 0, 100% 0, 50% 50%)', backgroundColor: '#facc15'}}></div> {/* Yellow Top */}
          <div className="absolute inset-0 bg-white" style={{clipPath: 'polygon(100% 0, 100% 100%, 50% 50%)', backgroundColor: '#3b82f6'}}></div> {/* Blue Right */}
          <div className="absolute inset-0 bg-white" style={{clipPath: 'polygon(0 100%, 100% 100%, 50% 50%)', backgroundColor: '#ef4444'}}></div> {/* Red Bottom */}
          <div className="absolute inset-0 bg-white" style={{clipPath: 'polygon(0 0, 0 100%, 50% 50%)', backgroundColor: '#22c55e'}}></div> {/* Green Left */}
      </div>
    </div>
  );
};

export default GameBoard;