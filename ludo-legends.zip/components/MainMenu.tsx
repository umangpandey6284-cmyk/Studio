import React from 'react';
import { User } from '../types';

interface MainMenuProps {
  user: User;
  onStartGame: (mode: string) => void;
  onOpenShop: () => void;
  onLogout: () => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ user, onStartGame, onOpenShop, onLogout }) => {
  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto p-6 space-y-6 animate-pop">
      {/* Header Profile */}
      <div className="w-full bg-gray-800 rounded-2xl p-4 flex items-center justify-between shadow-lg border border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-purple-400 to-pink-500 flex items-center justify-center text-xl font-bold">
            {user.avatar}
          </div>
          <div>
            <h2 className="font-bold text-lg">{user.username}</h2>
            <div className="flex items-center text-yellow-400 text-sm">
              <span className="mr-1">🪙</span> {user.coins}
            </div>
          </div>
        </div>
        <button onClick={onLogout} className="text-gray-400 hover:text-white text-sm">Logout</button>
      </div>

      {/* Hero Title */}
      <div className="text-center py-4">
        <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 filter drop-shadow-lg">
          LUDO LEGENDS
        </h1>
        <p className="text-gray-400 mt-2">Roll the dice, rule the board.</p>
      </div>

      {/* Game Modes */}
      <div className="grid grid-cols-2 gap-4 w-full">
        <button 
          onClick={() => onStartGame('SINGLE')}
          className="bg-gradient-to-br from-blue-500 to-blue-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-500/30 transform hover:-translate-y-1 transition-all"
        >
          <div className="text-3xl mb-2">🤖</div>
          <div className="font-bold">Vs Computer</div>
        </button>
        <button 
          onClick={() => onStartGame('LOCAL')}
          className="bg-gradient-to-br from-green-500 to-green-700 p-6 rounded-2xl shadow-lg hover:shadow-green-500/30 transform hover:-translate-y-1 transition-all"
        >
          <div className="text-3xl mb-2">👥</div>
          <div className="font-bold">Local 2P</div>
        </button>
        <button 
          onClick={() => onStartGame('ONLINE')} // Mocked
          className="bg-gradient-to-br from-purple-500 to-purple-700 p-6 rounded-2xl shadow-lg hover:shadow-purple-500/30 transform hover:-translate-y-1 transition-all col-span-2 relative overflow-hidden group"
        >
           <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"></div>
          <div className="text-3xl mb-2">🌍</div>
          <div className="font-bold">Online Multiplayer</div>
          <span className="absolute top-2 right-2 text-xs bg-yellow-500 text-black px-2 py-0.5 rounded-full font-bold">HOT</span>
        </button>
      </div>

      {/* Footer Actions */}
      <div className="flex w-full justify-between space-x-4">
        <button 
          onClick={onOpenShop}
          className="flex-1 bg-gray-700 p-4 rounded-xl flex flex-col items-center hover:bg-gray-600 transition-colors"
        >
          <span className="text-2xl">🛒</span>
          <span className="text-xs font-bold mt-1">Shop</span>
        </button>
        <button className="flex-1 bg-gray-700 p-4 rounded-xl flex flex-col items-center hover:bg-gray-600 transition-colors">
          <span className="text-2xl">🏆</span>
          <span className="text-xs font-bold mt-1">Rank</span>
        </button>
        <button className="flex-1 bg-gray-700 p-4 rounded-xl flex flex-col items-center hover:bg-gray-600 transition-colors">
          <span className="text-2xl">⚙️</span>
          <span className="text-xs font-bold mt-1">Settings</span>
        </button>
      </div>
    </div>
  );
};

export default MainMenu;