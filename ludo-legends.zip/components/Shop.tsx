import React from 'react';
import { ShopItem, User } from '../types';
import { SHOP_ITEMS } from '../constants';

interface ShopProps {
  user: User;
  onBuy: (item: ShopItem) => void;
  onClose: () => void;
}

const Shop: React.FC<ShopProps> = ({ user, onBuy, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 w-full max-w-lg rounded-3xl shadow-2xl border border-gray-700 overflow-hidden flex flex-col max-h-[80vh]">
        <div className="p-6 bg-gray-800 border-b border-gray-700 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white">Item Shop</h2>
            <p className="text-gray-400 text-sm">Customize your experience</p>
          </div>
          <div className="flex items-center space-x-2 bg-gray-900 px-4 py-2 rounded-full border border-gray-700">
            <span>🪙</span>
            <span className="font-bold text-yellow-400">{user.coins}</span>
          </div>
        </div>

        <div className="overflow-y-auto p-6 space-y-4">
          {SHOP_ITEMS.map((item) => {
            const owned = user.inventory.includes(item.id);
            const canAfford = user.coins >= item.price;

            return (
              <div key={item.id} className="bg-gray-800 p-4 rounded-xl flex items-center justify-between group hover:bg-gray-750 transition-colors border border-gray-700 hover:border-blue-500/50">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-700 rounded-lg flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-white">{item.name}</h3>
                    <p className="text-xs text-blue-400 font-semibold">{item.type}</p>
                  </div>
                </div>
                
                <button
                  disabled={owned || !canAfford}
                  onClick={() => onBuy(item)}
                  className={`px-4 py-2 rounded-lg font-bold text-sm transition-all ${
                    owned 
                      ? 'bg-green-500/20 text-green-500 cursor-default' 
                      : canAfford 
                        ? 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-lg shadow-yellow-500/20' 
                        : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {owned ? 'OWNED' : `${item.price} 🪙`}
                </button>
              </div>
            );
          })}
        </div>

        <div className="p-4 bg-gray-800 border-t border-gray-700">
          <button onClick={onClose} className="w-full bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 rounded-xl transition-colors">
            Close Shop
          </button>
        </div>
      </div>
    </div>
  );
};

export default Shop;