import { PlayerColor, ShopItem } from "./types";

// The main path loop is 52 cells.
export const PATH_LENGTH = 52;
export const VICTORY_PATH_LENGTH = 6;

// Safe zones (globally indexed 0-51)
// Standard Ludo safe zones are usually where players start their path + 8 tiles etc.
// Here we define star positions based on the standard board layout.
export const SAFE_ZONES = [0, 8, 13, 21, 26, 34, 39, 47];

// Mapping colors to their starting index on the global path (0-51)
export const START_INDICES: Record<PlayerColor, number> = {
  RED: 0,
  GREEN: 13,
  YELLOW: 26,
  BLUE: 39
};

export const COLORS = {
  RED: { bg: 'bg-red-500', text: 'text-red-500', border: 'border-red-600', shadow: 'shadow-red-500/50' },
  GREEN: { bg: 'bg-green-500', text: 'text-green-500', border: 'border-green-600', shadow: 'shadow-green-500/50' },
  YELLOW: { bg: 'bg-yellow-400', text: 'text-yellow-400', border: 'border-yellow-500', shadow: 'shadow-yellow-400/50' },
  BLUE: { bg: 'bg-blue-500', text: 'text-blue-500', border: 'border-blue-600', shadow: 'shadow-blue-500/50' },
};

export const SHOP_ITEMS: ShopItem[] = [
  { id: 'theme_dark', name: 'Neon Night', price: 500, type: 'THEME', icon: '🌙' },
  { id: 'theme_wood', name: 'Classic Wood', price: 300, type: 'THEME', icon: '🪵' },
  { id: 'av_king', name: 'King Avatar', price: 1000, type: 'AVATAR', icon: '👑' },
  { id: 'av_robot', name: 'Mecha Bot', price: 800, type: 'AVATAR', icon: '🤖' },
  { id: 'boost_xp', name: 'Double XP (1hr)', price: 200, type: 'BOOST', icon: '⚡' },
];

// Helper to map a path index to x,y grid coordinates (15x15 grid)
// This is a manual mapping of the standard Ludo board spiral/cross.
export const getGridCoordinates = (globalIndex: number): {x: number, y: number} => {
  // Hardcoded path mapping for a standard 15x15 Ludo board
  // (0,0) is top-left.
  // This path assumes RED starts bottom-left and moves UP.
  
  // Actually, standard Ludo:
  // Red (Bottom-Left Home) -> Starts at (1, 6) relative to bottom-left?
  // Let's define the 52 global cells coordinates manually for precision.
  
  // Starting from Red Start (which is usually cell 0 in logic)
  // Red Start: (6, 13) -> Wait, let's use a coordinate system where 0,0 is top-left.
  // Board is 15x15.
  
  // Let's visualize the "Cross".
  // Row 0-5: Left Box, Middle Col, Right Box
  // Row 6-8: Horizontal Path
  // Row 9-14: Left Box, Middle Col, Right Box
  
  const path: [number, number][] = [
    // Red Start (Moving Up)
    [6, 13], [6, 12], [6, 11], [6, 10], [6, 9], // 0-4
    [5, 9], // 5 (Turn right into top-left quadrant path) - wait, Ludo moves clockwise usually?
    // Let's use standard: Red (Bottom Left), Green (Top Left), Yellow (Top Right), Blue (Bottom Right)
    // Movement is Clockwise.
    
    // RED (Bottom Left) Start Position on Path: (1, 13) is invalid.
    // Let's trace from Red Start (index 0).
    // Red Start is usually adjacent to its home base.
    
    // Path 0-5 (Red Straight Up)
    [1, 13], [2, 13], [3, 13], [4, 13], [5, 13], // No, this is confusing.
    
    // Let's implement the specific coordinate map in the component logic instead.
    // We will use a visual cell renderer that knows map logic.
  ] as any; // Type assertion to skip empty check for now
  
  return { x: 0, y: 0};
};
