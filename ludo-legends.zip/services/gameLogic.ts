import { GameState, Player, Pawn, PlayerColor, PawnStatus } from "../types";
import { PATH_LENGTH, SAFE_ZONES, START_INDICES } from "../constants";

export const createInitialState = (playerConfigs: { name: string, color: PlayerColor, isBot: boolean }[]): GameState => {
  const players: Player[] = playerConfigs.map((cfg, idx) => ({
    id: `p-${idx}`,
    name: cfg.name,
    color: cfg.color,
    avatar: cfg.isBot ? '🤖' : '👤',
    isBot: cfg.isBot,
    hasFinished: false,
    rank: 0,
    pawns: Array(4).fill(null).map((_, pIdx) => ({
      id: pIdx,
      color: cfg.color,
      position: -1, // -1 means in base (HOME)
      status: PawnStatus.HOME,
      stepsMoved: 0
    }))
  }));

  return {
    players,
    currentPlayerIndex: 0,
    diceValue: null,
    waitingForDice: true,
    movingPawn: false,
    winners: [],
    logs: ['Game started!']
  };
};

export const rollDice = (): number => {
  return Math.floor(Math.random() * 6) + 1;
};

// Check if a move is valid for a specific pawn
export const isValidMove = (pawn: Pawn, diceValue: number): boolean => {
  if (pawn.status === PawnStatus.FINISHED) return false;
  
  // Must roll 6 to leave base
  if (pawn.status === PawnStatus.HOME) {
    return diceValue === 6;
  }
  
  // Check victory path overflow
  // stepsMoved counts total steps taken. Path length is 51 + 1 (entry) + 5 (victory) = 57?
  // Let's say max steps is 56 (reach center).
  const MAX_STEPS = 56; // 51 squares + 5 home column squares + 1 target
  
  if (pawn.stepsMoved + diceValue > MAX_STEPS) {
    return false;
  }
  
  return true;
};

// Calculate new position
export const getNewPosition = (currentPos: number, steps: number, color: PlayerColor): number => {
  // This logic manages the cyclic global index (0-51)
  // Logic is handled in the move function regarding "stepsMoved" to switch to local victory path
  return (currentPos + steps) % PATH_LENGTH;
};

export const hasValidMoves = (player: Player, diceValue: number): boolean => {
  return player.pawns.some(pawn => isValidMove(pawn, diceValue));
};
