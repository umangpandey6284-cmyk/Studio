export type PlayerColor = 'RED' | 'GREEN' | 'YELLOW' | 'BLUE';

export enum PawnStatus {
  HOME = 'HOME',
  ACTIVE = 'ACTIVE',
  FINISHED = 'FINISHED'
}

export interface Pawn {
  id: number;
  color: PlayerColor;
  position: number; // 0-51 for main path, 52-57 for victory path
  status: PawnStatus;
  stepsMoved: number;
}

export interface Player {
  id: string;
  name: string;
  color: PlayerColor;
  avatar: string;
  isBot: boolean;
  pawns: Pawn[];
  hasFinished: boolean;
  rank: number; // 0 if not finished
}

export interface GameState {
  players: Player[];
  currentPlayerIndex: number;
  diceValue: number | null;
  waitingForDice: boolean;
  movingPawn: boolean;
  winners: PlayerColor[];
  logs: string[];
}

export interface User {
  username: string;
  email: string;
  coins: number;
  wins: number;
  avatar: string;
  inventory: string[];
}

export interface ShopItem {
  id: string;
  name: string;
  price: number;
  type: 'THEME' | 'AVATAR' | 'BOOST';
  icon: string;
}

export type ViewState = 'AUTH' | 'MENU' | 'LOBBY' | 'GAME' | 'SHOP' | 'LEADERBOARD' | 'PROFILE';