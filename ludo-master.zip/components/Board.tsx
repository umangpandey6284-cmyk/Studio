import React from 'react';
import { BOARD_SIZE, GLOBAL_PATH, HOME_PATHS, SAFE_SPOTS, COLORS } from '../constants';
import { GameState, Piece as PieceType, PlayerColor } from '../types';
import { getPieceCoordinates } from '../utils/gameLogic';
import { motion, AnimatePresence } from 'framer-motion';

interface BoardProps {
  gameState: GameState;
  onPieceClick: (piece: PieceType) => void;
}

const Board: React.FC<BoardProps> = ({ gameState, onPieceClick }) => {
  // Helper to render the colored home bases
  const renderBase = (color: PlayerColor, rowStart: number, colStart: number) => {
    const isActive = gameState.players[gameState.currentTurnIndex].color === color;
    const isWinner = gameState.winner === color;
