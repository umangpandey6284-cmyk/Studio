import React from 'react';
import { motion } from 'framer-motion';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6 } from 'lucide-react';

interface DiceProps {
  value: number | null;
  rolling: boolean;
  onClick: () => void;
  disabled: boolean;
  color: string;
}

const Dice: React.FC<DiceProps> = ({ value, rolling, onClick, disabled, color }) => {
  const getIcon = (val: number) => {
    switch(val) {
      case 1: return <Dice1 className="w-full h-full" />;
      case 2: return <Dice2 className="w-full h-full" />;
      case 3: return <Dice3 className="w-full h-full" />;
      case 4: return <Dice4 className="w-full h-full" />;
      case 5: return <Dice5 className="w-full h-full" />;
      case 6: return <Dice6 className="w-full h-full" />;
      default: return <Dice1 className="w-full h-full" />;
    }
  };

  return (
    <div className="flex flex-col items-center justify-center gap-2">
      <motion.button
        whileHover={!disabled ? { scale: 1.1 } : {}}
        whileTap={!disabled ? { scale: 0.95 } : {}}
        animate={rolling ? { 
          rotate: [0, 90, 180, 270, 360], 
          scale: [1, 1.2, 1],
          transition: { repeat: Infinity, duration: 0.5 }
        } : { rotate: 0 }}
        onClick={onClick}
        disabled={disabled}
        className={`w-20 h-20 rounded-xl bg-white shadow-xl border-4 ${disabled ? 'border-gray-300 opacity-50 cursor-not-allowed' : `border-${color}-500 cursor-pointer`} flex items-center justify-center text-gray-800 transition-colors`}
      >
        {value ? getIcon(value) : <span className="text-sm font-bold text-gray-400">ROLL</span>}
      </motion.button>
      {!disabled && !rolling && !value && (
        <span className="text-sm font-semibold animate-bounce text-white">Tap to Roll!</span>
      )}
    </div>
  );
};

export default Dice;
