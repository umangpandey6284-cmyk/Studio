import { Coordinate, PlayerColor } from './types';

// The Ludo board is a 15x15 grid.
// We map the main 52-step path to coordinates (row, col).
// 0,0 is top-left.

export const BOARD_SIZE = 15;

// Defined manually to ensure perfect mapping to the visual grid
// The global path starts at Green's start position (1, 6) index 0 technically relative to global, 
// but let's define a universal path starting from coordinates (6,1) which is usually Red's start 
// or using a standard offset. 
//
// Let's use a standard path array of 52 coordinates starting from the cell 
// where Green enters the track (6,1) -> (6,0) is start usually? 
// Actually, let's trace the path clockwise or counter-clockwise?
// Ludo is usually clockwise.
//
// Path sequence (0 to 51) relative to the board grid.
// Let's assume index 0 is (6, 1) - The cell right of the start base of Red? 
// No, let's just map the visual track.

// Visual Grid path for the outer loop (52 steps)
// Starting from Red's start square and moving clockwise.
// Red Start: (13, 6). 
// Wait, standard board:
// Green (Top-Left), Red (Bottom-Left), Blue (Bottom-Right), Yellow (Top-Right)??
// Let's stick to: Green (TL), Yellow (TR), Blue (BR), Red (BL).
//
// Standard movement is Clockwise.
// Red starts at (13, 6) -> moves up.
// Green starts at (6, 1) -> moves right.
// Yellow starts at (1, 8) -> moves down.
// Blue starts at (8, 13) -> moves left.

export const PATH_COORDINATES: Coordinate[] = [
  // Red's Track (starts at index 0 for Red, but we need a global index)
  // Let's define global index 0 as Green's start point (6,1) to standardize.
  
  // Green side (6,1 to 6,5) then up (5,6 to 0,6) then right (0,7 to 0,8) then down (1,8 to 6,8)
  // This is getting complex. Let's map segments.
  
  // Segment 1 (Green Start area moving Right): (6,0) is start? Usually (6,1). 
  // Let's trace all 52 steps starting from Green's safe start (6, 1).
  { x: 6, y: 1 }, { x: 6, y: 2 }, { x: 6, y: 3 }, { x: 6, y: 4 }, { x: 6, y: 5 },
  { x: 5, y: 6 }, { x: 4, y: 6 }, { x: 3, y: 6 }, { x: 2, y: 6 }, { x: 1, y: 6 }, { x: 0, y: 6 },
  { x: 0, y: 7 }, { x: 0, y: 8 }, // Turning top
  { x: 1, y: 8 }, { x: 2, y: 8 }, { x: 3, y: 8 }, { x: 4, y: 8 }, { x: 5, y: 8 }, { x: 6, y: 8 }, // Down Yellow side
  { x: 6, y: 9 }, { x: 6, y: 10 }, { x: 6, y: 11 }, { x: 6, y: 12 }, { x: 6, y: 13 }, { x: 6, y: 14 }, // Right Yellow start
  { x: 7, y: 14 }, { x: 8, y: 14 }, // Turning right
  { x: 8, y: 13 }, { x: 8, y: 12 }, { x: 8, y: 11 }, { x: 8, y: 10 }, { x: 8, y: 9 }, // Left Blue side
  { x: 9, y: 8 }, { x: 10, y: 8 }, { x: 11, y: 8 }, { x: 12, y: 8 }, { x: 13, y: 8 }, { x: 14, y: 8 }, // Down Blue side
  { x: 14, y: 7 }, { x: 14, y: 6 }, // Turning bottom
  { x: 13, y: 6 }, { x: 12, y: 6 }, { x: 11, y: 6 }, { x: 10, y: 6 }, { x: 9, y: 6 }, { x: 8, y: 6 }, // Up Red side
  { x: 8, y: 5 }, { x: 8, y: 4 }, { x: 8, y: 3 }, { x: 8, y: 2 }, { x: 8, y: 1 }, { x: 8, y: 0 }, // Left Red side
  { x: 7, y: 0 }, { x: 6, y: 0 }  // Turning left back to start
];
// Wait, the above logic had a small gap. 
// Standard Ludo Path:
// 1. Green Start: (6, 1). Moves Right to (6,5). (5 steps).
// 2. Up to (0,6). (6 steps).
// 3. Right to (0,8). (2 steps).
// 4. Down to (6,8). (6 steps).
// 5. Right to (6,14). (6 steps).
// 6. Down to (8,14). (2 steps).
// 7. Left to (8,9). (6 steps).
// 8. Down to (14,8). (6 steps).
// 9. Left to (14,6). (2 steps).
// 10. Up to (8,6). (6 steps).
// 11. Left to (8,0). (6 steps).
// 12. Up to (6,0). (2 steps).
// Total: 5 + 6 + 2 + 6 + 6 + 2 + 6 + 6 + 2 + 6 + 6 + 2 = 55 steps? No, the loop is 52.
// Let's refine the specific Ludo grid index. 

// Global Path Indices (0-51) starting from Green Start (6, 1)
export const GLOBAL_PATH: Coordinate[] = [
  // Green Straight (5 cells)
  { x: 6, y: 1 }, { x: 6, y: 2 }, { x: 6, y: 3 }, { x: 6, y: 4 }, { x: 6, y: 5 },
  // Up towards Yellow (6 cells)
  { x: 5, y: 6 }, { x: 4, y: 6 }, { x: 3, y: 6 }, { x: 2, y: 6 }, { x: 1, y: 6 }, { x: 0, y: 6 },
  // Turn Top (1 cell)
  { x: 0, y: 7 },
  // Down from Yellow (6 cells)
  { x: 0, y: 8 }, { x: 1, y: 8 }, { x: 2, y: 8 }, { x: 3, y: 8 }, { x: 4, y: 8 }, { x: 5, y: 8 },
  // Right towards Blue (5 cells)
  { x: 6, y: 9 }, { x: 6, y: 10 }, { x: 6, y: 11 }, { x: 6, y: 12 }, { x: 6, y: 13 }, 
  // Turn Right Edge (1 cell)
  { x: 7, y: 14 }, // This is usually a safe spot or star. Actually Blue Start is usually (8, 13)
  // Let's continue loop
  { x: 8, y: 13 }, { x: 8, y: 12 }, { x: 8, y: 11 }, { x: 8, y: 10 }, { x: 8, y: 9 },
  // Down towards Red (6 cells)
  { x: 9, y: 8 }, { x: 10, y: 8 }, { x: 11, y: 8 }, { x: 12, y: 8 }, { x: 13, y: 8 }, { x: 14, y: 8 },
  // Turn Bottom (1 cell)
  { x: 14, y: 7 },
  // Up from Red (6 cells)
  { x: 14, y: 6 }, { x: 13, y: 6 }, { x: 12, y: 6 }, { x: 11, y: 6 }, { x: 10, y: 6 }, { x: 9, y: 6 },
  // Left towards Green (5 cells)
  { x: 8, y: 5 }, { x: 8, y: 4 }, { x: 8, y: 3 }, { x: 8, y: 2 }, { x: 8, y: 1 },
  // Turn Left Edge (1 cell)
  { x: 7, y: 0 } 
  // Next is back to { x: 6, y: 1 } which is index 0.
];

// Start offsets for each player on the GLOBAL_PATH
// Green starts at index 0.
// Yellow starts at index 13.
// Blue starts at index 26.
// Red starts at index 39.
export const PLAYER_START_OFFSETS: Record<PlayerColor, number> = {
  green: 0,
  yellow: 13,
  blue: 26,
  red: 39,
};

// Home stretch paths (indices 52-57 in local piece state)
// Each player has a unique path to the center.
export const HOME_PATHS: Record<PlayerColor, Coordinate[]> = {
  green: [{ x: 7, y: 1 }, { x: 7, y: 2 }, { x: 7, y: 3 }, { x: 7, y: 4 }, { x: 7, y: 5 }, { x: 7, y: 6 }],
  yellow: [{ x: 1, y: 7 }, { x: 2, y: 7 }, { x: 3, y: 7 }, { x: 4, y: 7 }, { x: 5, y: 7 }, { x: 6, y: 7 }],
  blue: [{ x: 7, y: 13 }, { x: 7, y: 12 }, { x: 7, y: 11 }, { x: 7, y: 10 }, { x: 7, y: 9 }, { x: 7, y: 8 }],
  red: [{ x: 13, y: 7 }, { x: 12, y: 7 }, { x: 11, y: 7 }, { x: 10, y: 7 }, { x: 9, y: 7 }, { x: 8, y: 7 }],
};

export const YARD_COORDINATES: Record<PlayerColor, Coordinate[]> = {
  green: [{ x: 2, y: 2 }, { x: 2, y: 3 }, { x: 3, y: 2 }, { x: 3, y: 3 }],
  yellow: [{ x: 2, y: 11 }, { x: 2, y: 12 }, { x: 3, y: 11 }, { x: 3, y: 12 }],
  blue: [{ x: 11, y: 11 }, { x: 11, y: 12 }, { x: 12, y: 11 }, { x: 12, y: 12 }],
  red: [{ x: 11, y: 2 }, { x: 11, y: 3 }, { x: 12, y: 2 }, { x: 12, y: 3 }],
};

export const SAFE_SPOTS = [
  0, 8, 13, 21, 26, 34, 39, 47 // Global indices that are safe (Stars)
];

export const COLORS = {
  green: { base: 'bg-green-500', dark: 'bg-green-600', text: 'text-green-500', border: 'border-green-500', light: 'bg-green-100' },
  yellow: { base: 'bg-yellow-400', dark: 'bg-yellow-500', text: 'text-yellow-500', border: 'border-yellow-400', light: 'bg-yellow-100' },
  blue: { base: 'bg-blue-500', dark: 'bg-blue-600', text: 'text-blue-500', border: 'border-blue-500', light: 'bg-blue-100' },
  red: { base: 'bg-red-500', dark: 'bg-red-600', text: 'text-red-500', border: 'border-red-500', light: 'bg-red-100' },
};
