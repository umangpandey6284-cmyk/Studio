export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export interface Piece {
  id: string;
  color: PlayerColor;
  position: number; // -1 = yard, 0-51 = main track, 52-57 = home stretch, 99 = home/finished
}

export interface Player {
  color: PlayerColor;
  name: string;
  pieces: Piece[];
  hasFinished: boolean;
}

export interface GameState {
  players: Player[];
  currentTurnIndex: number;
  diceValue: number | null;
  phase: 'ROLL_DICE' | 'SELECT_PIECE' | 'MOVING' | 'WIN';
  lastDiceRoll: number | null;
  winner: PlayerColor | null;
  log: string[];
}

export interface Coordinate {
  x: number;
  y: number;
}
