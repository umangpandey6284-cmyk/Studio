import { GLOBAL_PATH, HOME_PATHS, PLAYER_START_OFFSETS, SAFE_SPOTS, YARD_COORDINATES } from '../constants';
import { GameState, Piece, PlayerColor, Coordinate } from '../types';

export const getPieceCoordinates = (piece: Piece): Coordinate => {
  if (piece.position === -1) {
    // In Yard
    return YARD_COORDINATES[piece.color][parseInt(piece.id.split('-')[1])];
  }
  
  if (piece.position >= 0 && piece.position <= 51) {
    // On Global Path
    // We need to convert local path index to global index
    // BUT the piece position stored is usually "steps taken".
    // Let's assume piece.position is Steps Taken from Start.
    // 0 = Start position on track.
    
    const startOffset = PLAYER_START_OFFSETS[piece.color];
    const globalIndex = (startOffset + piece.position) % 52;
    return GLOBAL_PATH[globalIndex];
  }
  
  if (piece.position >= 52 && piece.position < 58) {
     // Home Stretch
     const homeIndex = piece.position - 52;
     return HOME_PATHS[piece.color][homeIndex];
  }
  
  if (piece.position === 99) {
    // Finished (center of home triangle usually, but lets put them at end of home path for now or a special spot)
    // We'll map 99 to the last spot of home path for visualization or a center cluster
    const last = HOME_PATHS[piece.color][5];
    return last; // Overlap at end for now
  }

  return { x: 0, y: 0 };
};

// Returns the global index on the track if valid, or null if in yard/home
export const getGlobalPosition = (piece: Piece): number | null => {
  if (piece.position >= 0 && piece.position <= 50) { // 50 is just before turning home
     return (PLAYER_START_OFFSETS[piece.color] + piece.position) % 52;
  }
  return null;
};

export const canMovePiece = (piece: Piece, diceValue: number): boolean => {
  if (piece.position === 99) return false; // Already finished

  if (piece.position === -1) {
    return diceValue === 6; // Can only leave yard on a 6
  }

  // Check if move exceeds home
  if (piece.position + diceValue > 57) {
    return false;
  }

  return true;
};

export const checkCaptures = (
  movingPiece: Piece, 
  allPlayers: any[], 
  finalPosition: number
): Piece | null => {
  // Capture logic only applies on main track (0-50 for the moving piece relative to start?)
  // Actually captures happen based on Global Index overlap.
  
  if (finalPosition > 50) return null; // Safe in home stretch

  const movingGlobalIndex = (PLAYER_START_OFFSETS[movingPiece.color] + finalPosition) % 52;

  // Check if this global index is a safe spot
  if (SAFE_SPOTS.includes(movingGlobalIndex)) return null;

  for (const player of allPlayers) {
    if (player.color === movingPiece.color) continue; // Don't capture self

    for (const enemyPiece of player.pieces) {
      if (enemyPiece.position === -1 || enemyPiece.position > 50 || enemyPiece.position === 99) continue;

      const enemyGlobalIndex = (PLAYER_START_OFFSETS[player.color] + enemyPiece.position) % 52;

      if (movingGlobalIndex === enemyGlobalIndex) {
        return enemyPiece; // Captured!
      }
    }
  }

  return null;
};
